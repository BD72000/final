import os
import io
import numpy as np
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from PIL import Image
import tensorflow as tf  # or from tflite_runtime.interpreter import Interpreter

app = FastAPI()

# --------- CONFIG ---------
TFLITE_MODEL_PATH = "model.tflite"

CLASS_NAMES = ['Amritmahal',
 'Ayrshire',
 'Banni',
 'Bargur',
 'Bhadawari',
 'Dangi',
 'Deoni',
 'Gir',
 'Hallikar',
 'Hariana',
 'Himachali Pahari',
 'Kangayam',
 'Kankrej',
 'Kenkatha',
 'Khariar',
 'Khillari',
 'Konkan Kapila',
 'Kosali',
 'Krishna_Valley',
 'Ladakhi',
 'Lakhimi',
 'Malnad_gidda',
 'Mewati',
 'Murrah',
 'Nagpuri',
 'Nari',
 'Nimari',
 'Ongole',
 'Poda Thirupu',
 'Pulikulam',
 'Punganur',
 'Purnea',
 'Rathi',
 'Red kandhari',
 'Red_Sindhi',
 'Sahiwal',
 'Shweta Kapila',
 'Surti',
 'Tharparkar',
 'Toda',
 'Umblachery',
 'Vechur',
 'bachaur',
 'badri',
 'bhelai',
 'dagri',
 'gangatari',
 'gaolao',
 'ghumsari',
 'kherigarh',
 'malvi',
 'motu',
 'nagori',
 'ponwar',
 'siri',
 'thutho']
# ---------------------------

# Load TFLite model once at startup
interpreter = tf.lite.Interpreter(model_path=TFLITE_MODEL_PATH)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

INPUT_SHAPE = input_details[0]["shape"]  # e.g. [1, 224, 224, 3]
TARGET_H = int(INPUT_SHAPE[1])
TARGET_W = int(INPUT_SHAPE[2])

def preprocess_image(image: Image.Image) -> np.ndarray:
    image = image.resize((TARGET_W, TARGET_H))
    image = image.convert("RGB")
    x = np.array(image, dtype=np.float32)
    x = x / 255.0      # change if you used different normalization
    x = np.expand_dims(x, axis=0)
    return x

@app.get("/")
def root():
    return {"status": "ok"}

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid image file")

    input_tensor = preprocess_image(image)

    interpreter.set_tensor(input_details[0]["index"], input_tensor)
    interpreter.invoke()
    output_data = interpreter.get_tensor(output_details[0]["index"])

    probs = np.squeeze(output_data)
    class_idx = int(np.argmax(probs))
    confidence = float(probs[class_idx])

    if 0 <= class_idx < len(CLASS_NAMES):
        class_name = CLASS_NAMES[class_idx]
    else:
        class_name = f"class_{class_idx}"

    return JSONResponse(
        {
            "class_index": class_idx,
            "class_name": class_name,
            "confidence": confidence,
        }
    )

# This is ONLY for local debug. Cloud Run will use `CMD` from Dockerfile.
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)
