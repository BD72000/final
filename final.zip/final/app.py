import os
import numpy as np
from PIL import Image
from flask import Flask, request, jsonify
import tensorflow as tf

# -----------------------------
# Config
# -----------------------------
# Path to your TFLite model inside the container
TFLITE_MODEL_PATH = os.getenv("TFLITE_MODEL_PATH", "model.tflite")

# ⚠️ TODO: Put your actual class names here in correct order
# Example:
# class_names = ["Sahiwal", "Gir", "Red Sindhi", ...]
class_names = ['Amritmahal',
 'Ayrshire',
 'Banni',
 'Bargur',
 'Bhadawari',
 'Dangi',
 'Deoni',
 'Gir',
 'Hallikar',
 'Hariana',
 'Himachali Pahari',
 'Kangayam',
 'Kankrej',
 'Kenkatha',
 'Khariar',
 'Khillari',
 'Konkan Kapila',
 'Kosali',
 'Krishna_Valley',
 'Ladakhi',
 'Lakhimi',
 'Malnad_gidda',
 'Mewati',
 'Murrah','Nagpuri','Nari','Nimari',
 'Ongole',
 'Poda Thirupu',
 'Pulikulam',
 'Punganur',
 'Purnea',
 'Rathi',
 'Red kandhari',
 'Red_Sindhi',
 'Sahiwal',
 'Shweta Kapila',
 'Surti',
 'Tharparkar',
 'Toda',
 'Umblachery',
 'Vechur',
 'bachaur',
 'badri',
 'bhelai',
 'dagri',
 'gangatari',
 'gaolao',
 'ghumsari',
 'kherigarh',
 'malvi',
 'motu','nagori','ponwar','siri','thutho']

IMG_SIZE = int(os.getenv("IMG_SIZE", 256))

# -----------------------------
# Load TFLite Interpreter once
# -----------------------------
interpreter = tf.lite.Interpreter(model_path=TFLITE_MODEL_PATH)
interpreter.allocate_tensors()

input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

# -----------------------------
# Helper functions
# -----------------------------
def preprocess_image(image: Image.Image, img_size: int = 256) -> np.ndarray:
    """
    Resize and convert image to float32 array suitable for TFLite model.
    Assumes model expects [1, img_size, img_size, 3] float32.
    """
    image = image.convert("RGB")
    image = image.resize((img_size, img_size))
    img_array = np.array(image, dtype=np.float32)

    # If you did normalization during training (e.g. /255.0), do it here:
    # img_array = img_array / 255.0

    img_array = np.expand_dims(img_array, axis=0)
    return img_array


def predict_image(image: Image.Image):
    # Preprocess
    input_data = preprocess_image(image, IMG_SIZE)

    # Set input tensor
    interpreter.set_tensor(input_details[0]["index"], input_data)

    # Run inference
    interpreter.invoke()

    # Get predictions
    predictions = interpreter.get_tensor(output_details[0]["index"])[0]

    # Get top prediction
    pred_idx = int(np.argmax(predictions))
    confidence = float(predictions[pred_idx]) * 100.0

    # Map index to class name (with safety check)
    if 0 <= pred_idx < len(class_names):
        pred_name = class_names[pred_idx]
    else:
        pred_name = f"class_{pred_idx}"

    return pred_name, confidence, predictions.tolist()

# -----------------------------
# Flask App
# -----------------------------
app = Flask(__name__)


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "message": "TFLite model is running.",
        "predict_endpoint": "/predict",
        "method": "POST",
        "content_type": "multipart/form-data",
        "field_name": "image"
    })


@app.route("/predict", methods=["POST"])
def predict():
    if "image" not in request.files:
        return jsonify({"error": "No image file part in the request. Use field name 'image'."}), 400

    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error": "No selected file."}), 400

    try:
        image = Image.open(file.stream)
    except Exception as e:
        return jsonify({"error": f"Cannot open image. Details: {str(e)}"}), 400

    try:
        pred_name, confidence, raw_scores = predict_image(image)
    except Exception as e:
        return jsonify({"error": f"Inference failed. Details: {str(e)}"}), 500

    return jsonify({
        "predicted_class": pred_name,
        "confidence_percent": confidence,
        "raw_scores": raw_scores
    })


if __name__ == "__main__":
    # For local testing: python app.py
    port = int(os.getenv("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
